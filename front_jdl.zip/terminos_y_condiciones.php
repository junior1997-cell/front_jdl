<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from htmlstream.com/front/page-terms.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 19 May 2021 14:20:42 GMT -->
<head>
  <!-- Title -->
  <title>Terms &amp; Conditions | JDL Technology</title>

  <!-- Required Meta Tags Always Come First -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <?php $title = ">Detalle Producto"; require 'head.php'; ?>

</head>
<body>
  <!-- ========== HEADER ========== -->
  <header id="header" class="header header-box-shadow-on-scroll header-abs-top header-bg-transparent header-show-hide"
          data-hs-header-options='{
            "fixMoment": 1000,
            "fixEffect": "slide"
          }'>
    <!-- Search -->
    <?php /* require 'div_search.php'; */ ?>
    <!-- End Search -->

    <div class="header-section">
      <!-- Topbar -->
      <?php /* require 'div_topbar.php'; */ ?>
      <!-- End Topbar -->

      <div id="logoAndNav" class="container">
        <!-- Nav -->
        <?php require 'nav_v1.php'; ?>
        <!-- End Nav -->
      </div>
    </div>
  </header>
  <!-- ========== END HEADER ========== -->

  <!-- ========== MAIN ========== -->
  <main id="content" role="main">
    <!-- Hero Section -->
    <div class="bg-img-hero" style="background-image: url(assets/svg/components/abstract-shapes-12.svg);">
      <div class="container space-top-3 space-top-lg-4 space-bottom-2 position-relative z-index-2">
        <div class="w-md-80 w-lg-60 text-center mx-md-auto">
          <h1>Front Terms &amp; Conditions</h1>
          <p>Effective date: 1 January 2019</p>
        </div>
      </div>
    </div>
    <!-- End Hero Section -->

    <!-- Terms Content Section -->
    <div class="container space-2 space-bottom-lg-3">
      <div class="row">
        <div id="stickyBlockStartPoint" class="col-md-4 col-lg-3 mb-7 mb-md-0">
          <!-- Nav -->
          <nav class="js-sticky-block card card-bordered"
               data-hs-sticky-block-options='{
                 "parentSelector": "#stickyBlockStartPoint",
                 "targetSelector": "#logoAndNav",
                 "breakpoint": "md",
                 "startPoint": "#stickyBlockStartPoint",
                 "endPoint": "#stickyBlockEndPoint",
                 "stickyOffsetTop": 24,
                 "stickyOffsetBottom": 24
               }'>
            <div class="card-body">
              <ul class="js-scroll-nav nav nav-sm nav-x-0 flex-column">
                <li class="nav-item">
                  <a class="nav-link font-weight-bold mb-2" href="#services">1. Using our services</a>

                  <ol class="navbar-nav">
                    <li class="nav-item">
                      <a class="nav-link mb-2" href="#personal-data">A. Personal Data that we collect about you</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link mb-2" href="#information">B. Information that we collect automatically on our Sites</a>
                    </li>
                  </ol>
                </li>
                <li class="nav-item">
                  <a class="nav-link font-weight-bold mb-2" href="#privacy">2. Privacy and copyright protection</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link font-weight-bold mb-2" href="#yourContent">3. Your content in our services</a>
                </li>
              </ul>
            </div>
          </nav>
          <!-- End Nav -->
        </div>

        <div class="col-md-8 col-lg-9">
          <div id="intro" class="space-bottom-1">
            <!-- Title -->
            <div class="mb-3">
              <h2 class="h3">Welcome to Front</h2>
            </div>
            <!-- End Title -->

            <p>Thanks for using our products and services ("Services"). The Services are provided by Pixeel Ltd. ("Front"), located at 153 Williamson Plaza, Maggieberg, MT 09514, England, United Kingdom.
            <p>By using our Services, you are agreeing to these terms. Please read them carefully.</p>
            <p>Our Services are very diverse, so sometimes additional terms or product requirements (including age requirements) may apply. Additional terms will be available with the relevant Services, and those additional terms become part of your agreement with us if you use those Services.</p>
          </div>

          <div id="services" class="space-bottom-1">
            <!-- Title -->
            <div class="mb-3">
              <h3>1. Using our services</h3>
            </div>
            <!-- End Title -->

            <p>You must follow any policies made available to you within the Services.</p>
            <p>Don't misuse our Services. For example, don't interfere with our Services or try to access them using a method other than the interface and the instructions that we provide. You may use our Services only as permitted by law, including applicable export and re-export control laws and regulations. We may suspend or stop providing our Services to you if you do not comply with our terms or policies or if we are investigating suspected misconduct.</p>
            <p>Using our Services does not give you ownership of any intellectual property rights in our Services or the content you access. You may not use content from our Services unless you obtain permission from its owner or are otherwise permitted by law. These terms do not grant you the right to use any branding or logos used in our Services. Don't remove, obscure, or alter any legal notices displayed in or along with our Services.</p>

            <!-- Title -->
            <div id="personal-data" class="mb-3">
              <h4>A. Personal Data that we collect about you.</h4>
            </div>
            <!-- End Title -->

            <p>Personal Data is any information that relates to an identified or identifiable individual. The Personal Data that you provide directly to us through our Sites will be apparent from the context in which you provide the data. In particular:</p>

            <ul>
              <li class="pb-2">When you register for a Front account we collect your full name, email address, and account log-in credentials.</li>
              <li class="pb-2">When you fill-in our online form to contact our sales team, we collect your full name, work email, country, and anything else you tell us about your project, needs and timeline.</li>
              <li class="pb-2">When you use the "Remember Me" feature of Front Checkout, we collect your email address, payment card number, CVC code and expiration date.</li>
            </ul>

            <p>When you respond to Front emails or surveys we collect your email address, name and any other information you choose to include in the body of your email or responses. If you contact us by phone, we will collect the phone number you use to call Front. If you contact us by phone as a Front User, we may collect additional information in order to verify your identity.</p>

            <!-- Title -->
            <div id="information" class="mb-3">
              <h4>B. Information that we collect automatically on our Sites.</h4>
            </div>
            <!-- End Title -->

            <p>We also may collect information about your online activities on websites and connected devices over time and across third-party websites, devices, apps and other online features and services. We use Google Analytics on our Sites to help us analyze Your use of our Sites and diagnose technical issues.</p>

            <p>To learn more about the cookies that may be served through our Sites and how You can control our use of cookies and third-party analytics, please see our Cookie Policy.</p>
          </div>

          <div id="privacy" class="space-bottom-1">
            <!-- Title -->
            <div class="mb-3">
              <h3>2. Privacy and copyright protection</h3>
            </div>
            <!-- End Title -->

            <p>Front's privacy policies explain how we treat your personal data and protect your privacy when you use our Services. By using our Services, you agree that Front can use such data in accordance with our privacy policies.</p>
            <p>We respond to notices of alleged copyright infringement and terminate accounts of repeat infringers according to the process set out in the U.S. Digital Millennium Copyright Act.</p>
            <p>We provide information to help copyright holders manage their intellectual property online. If you think somebody is violating your copyrights and want to notify us, you can find information about submitting notices and Front's policy about responding to notices in <a href="demo-help-desk/index.php">our Help Center</a>.</p>
          </div>

          <div id="yourContent">
            <!-- Title -->
            <div class="mb-3">
              <h3>3. Your content in our services</h3>
            </div>
            <!-- End Title -->

            <p>Some of our Services allow you to upload, submit, store, send or receive content. You retain ownership of any intellectual property rights that you hold in that content. In short, what belongs to you stays yours.</p>
            <p>When you upload, submit, store, send or receive content to or through our Services, you give Front (and those we work with) a worldwide license to use, host, store, reproduce, modify, create derivative works (such as those resulting from translations, adaptations or other changes we make so that your content works better with our Services), communicate, publish, publicly perform, publicly display and distribute such content. The rights you grant in this license are for the limited purpose of operating, promoting, and improving our Services, and to develop new ones. This license continues even if you stop using our Services (for example, for a business listing you have added to Front Maps). Some Services may offer you ways to access and remove content that has been provided to that Service. Also, in some of our Services, there are terms or settings that narrow the scope of our use of the content submitted in those Services. Make sure you have the necessary rights to grant us this license for any content that you submit to our Services.</p>
          </div>

          <!-- Sticky Block End Point -->
          <div id="stickyBlockEndPoint"></div>
        </div>
      </div>
    </div>
    <!-- End Terms Content Section -->
  </main>
  <!-- ========== END MAIN ========== -->

  <!-- ========== FOOTER ========== -->
  <footer class="bg-dark">
    <div class="container">
      <div class="space-top-2 space-bottom-1 space-bottom-lg-2">
        <div class="row justify-content-lg-between">
          <div class="col-lg-3 ml-lg-auto mb-5 mb-lg-0">
            <!-- Logo -->
            <div class="mb-4">
              <a href="index.php" aria-label="Front">
                <img class="brand" src="assets/svg/logos/logo-white.svg" alt="Logo">
              </a>
            </div>
            <!-- End Logo -->

            <!-- Nav Link -->
            <ul class="nav nav-sm nav-x-0 nav-white flex-column">
              <li class="nav-item">
                <a class="nav-link media" href="javascript:;">
                    <span class="media">
                      <span class="fas fa-location-arrow mt-1 mr-2"></span>
                      <span class="media-body">
                        153 Williamson Plaza, Maggieberg
                      </span>
                    </span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link media" href="tel:1-062-109-9222">
                    <span class="media">
                      <span class="fas fa-phone-alt mt-1 mr-2"></span>
                      <span class="media-body">
                        +1 (062) 109-9222
                      </span>
                    </span>
                </a>
              </li>
            </ul>
            <!-- End Nav Link -->
          </div>

          <div class="col-6 col-md-3 col-lg mb-5 mb-lg-0">
            <h5 class="text-white">Company</h5>

            <!-- Nav Link -->
            <ul class="nav nav-sm nav-x-0 nav-white flex-column">
              <li class="nav-item"><a class="nav-link" href="#">About</a></li>
              <li class="nav-item"><a class="nav-link" href="#">Careers <span class="badge badge-primary ml-1">We're hiring</span></a></li>
              <li class="nav-item"><a class="nav-link" href="#">Blog</a></li>
              <li class="nav-item"><a class="nav-link" href="#">Customers</a></li>
              <li class="nav-item"><a class="nav-link" href="#">Hire us</a></li>
            </ul>
            <!-- End Nav Link -->
          </div>

          <div class="col-6 col-md-3 col-lg mb-5 mb-lg-0">
            <h5 class="text-white">Features</h5>

            <!-- Nav Link -->
            <ul class="nav nav-sm nav-x-0 nav-white flex-column">
              <li class="nav-item"><a class="nav-link" href="#">Press</a></li>
              <li class="nav-item"><a class="nav-link" href="#">Release notes</a></li>
              <li class="nav-item"><a class="nav-link" href="#">Integrations</a></li>
              <li class="nav-item"><a class="nav-link" href="#">Pricing</a></li>
            </ul>
            <!-- End Nav Link -->
          </div>

          <div class="col-6 col-md-3 col-lg">
            <h5 class="text-white">Documentation</h5>

            <!-- Nav Link -->
            <ul class="nav nav-sm nav-x-0 nav-white flex-column">
              <li class="nav-item"><a class="nav-link" href="#">Support</a></li>
              <li class="nav-item"><a class="nav-link" href="#">Docs</a></li>
              <li class="nav-item"><a class="nav-link" href="#">Status</a></li>
              <li class="nav-item"><a class="nav-link" href="#">API Reference</a></li>
              <li class="nav-item"><a class="nav-link" href="#">Tech Requirements</a></li>
            </ul>
            <!-- End Nav Link -->
          </div>

          <div class="col-6 col-md-3 col-lg">
            <h5 class="text-white">Resources</h5>

            <!-- Nav Link -->
            <ul class="nav nav-sm nav-x-0 nav-white flex-column">
              <li class="nav-item">
                <a class="nav-link" href="#">
                    <span class="media align-items-center">
                      <i class="fa fa-info-circle mr-2"></i>
                      <span class="media-body">Help</span>
                    </span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">
                    <span class="media align-items-center">
                      <i class="fa fa-user-circle mr-2"></i>
                      <span class="media-body">Your Account</span>
                    </span>
                </a>
              </li>
            </ul>
            <!-- End Nav Link -->
          </div>
        </div>
      </div>

      <hr class="opacity-xs my-0">

      <div class="space-1">
        <div class="row align-items-md-center mb-7">
          <div class="col-md-6 mb-4 mb-md-0">
            <!-- Nav Link -->
            <ul class="nav nav-sm nav-white nav-x-sm align-items-center">
              <li class="nav-item">
                <a class="nav-link" href="#">Privacy &amp; Policy</a>
              </li>
              <li class="nav-item opacity mx-3">&#47;</li>
              <li class="nav-item">
                <a class="nav-link" href="#">Terms</a>
              </li>
              <li class="nav-item opacity mx-3">&#47;</li>
              <li class="nav-item">
                <a class="nav-link" href="#">Site Map</a>
              </li>
            </ul>
            <!-- End Nav Link -->
          </div>

          <div class="col-md-6 text-md-right">
            <ul class="list-inline mb-0">
              <!-- Social Networks -->
              <li class="list-inline-item">
                <a class="btn btn-xs btn-icon btn-soft-light" href="#">
                  <i class="fab fa-facebook-f"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-xs btn-icon btn-soft-light" href="#">
                  <i class="fab fa-google"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-xs btn-icon btn-soft-light" href="#">
                  <i class="fab fa-twitter"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a class="btn btn-xs btn-icon btn-soft-light" href="#">
                  <i class="fab fa-github"></i>
                </a>
              </li>
              <!-- End Social Networks -->

              <!-- Language -->
              <li class="list-inline-item">
                <div class="hs-unfold">
                  <a class="js-hs-unfold-invoker dropdown-toggle btn btn-xs btn-soft-light" href="javascript:;"
                     data-hs-unfold-options='{
                        "target": "#footerLanguage",
                        "type": "css-animation",
                        "animationIn": "slideInDown"
                       }'>
                    <img class="dropdown-item-icon" src="assets/vendor/flag-icon-css/flags/4x3/us.svg" alt="United States Flag">
                    <span>United States</span>
                  </a>

                  <div id="footerLanguage" class="hs-unfold-content dropdown-menu dropdown-unfold dropdown-menu-bottom mb-2">
                    <a class="dropdown-item active" href="#">English</a>
                    <a class="dropdown-item" href="#">Deutsch</a>
                    <a class="dropdown-item" href="#">Español</a>
                    <a class="dropdown-item" href="#">Français</a>
                    <a class="dropdown-item" href="#">Italiano</a>
                    <a class="dropdown-item" href="#">日本語</a>
                    <a class="dropdown-item" href="#">한국어</a>
                    <a class="dropdown-item" href="#">Nederlands</a>
                    <a class="dropdown-item" href="#">Português</a>
                    <a class="dropdown-item" href="#">Русский</a>
                  </div>
                </div>
              </li>
              <!-- End Language -->
            </ul>
          </div>
        </div>

        <!-- Copyright -->
        <div class="w-md-75 text-lg-center mx-lg-auto">
          <p class="text-white opacity-sm small">&copy; Front. 2020 Htmlstream. All rights reserved.</p>
          <p class="text-white opacity-sm small">When you visit or interact with our sites, services or tools, we or our authorised service providers may use cookies for storing information to help provide you with a better, faster and safer experience and for marketing purposes.</p>
        </div>
        <!-- End Copyright -->
      </div>
    </div>
  </footer>
  <!-- ========== END FOOTER ========== -->

  <!-- ========== SECONDARY CONTENTS ========== -->
  <!-- Sign Up Modal -->
  <div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <!-- Header -->
        <div class="modal-close">
          <button type="button" class="btn btn-icon btn-sm btn-ghost-secondary" data-dismiss="modal" aria-label="Close">
            <svg width="10" height="10" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
              <path fill="currentColor" d="M11.5,9.5l5-5c0.2-0.2,0.2-0.6-0.1-0.9l-1-1c-0.3-0.3-0.7-0.3-0.9-0.1l-5,5l-5-5C4.3,2.3,3.9,2.4,3.6,2.6l-1,1 C2.4,3.9,2.3,4.3,2.5,4.5l5,5l-5,5c-0.2,0.2-0.2,0.6,0.1,0.9l1,1c0.3,0.3,0.7,0.3,0.9,0.1l5-5l5,5c0.2,0.2,0.6,0.2,0.9-0.1l1-1 c0.3-0.3,0.3-0.7,0.1-0.9L11.5,9.5z"/>
            </svg>
          </button>
        </div>
        <!-- End Header -->

        <!-- Body -->
        <div class="modal-body p-sm-5">
          <form class="js-validate">
            <!-- Sign in -->
            <div id="signinModalForm">
              <div class="text-center mb-5">
                <h2>Sign in</h2>
                <p>Don't have an account yet?
                  <a class="js-animation-link" href="javascript:;"
                     data-hs-show-animation-options='{
                         "targetSelector": "#signupModalForm",
                         "groupName": "idForm"
                       }'>Sign up here</a>
                </p>
              </div>

              <a class="btn btn-block btn-white mb-2" href="#">
                  <span class="d-flex justify-content-center align-items-center">
                    <img class="avatar avatar-xss mr-2" src="assets/svg/brands/google.svg" alt="Image Description">
                    Sign in with Google
                  </span>
              </a>

              <a class="js-animation-link btn btn-block btn-primary mb-2" href="#"
                 data-hs-show-animation-options='{
                     "targetSelector": "#signinWithEmailModalForm",
                     "groupName": "idForm"
                   }'>Sign in with Email</a>
            </div>
            <!-- End Sign in -->

            <!-- Sign in with Modal -->
            <div id="signinWithEmailModalForm" style="display: none; opacity: 0;">
              <div class="text-center mb-5">
                <h2>Sign in</h2>
                <p>Don't have an account yet?
                  <a class="js-animation-link" href="javascript:;"
                     data-hs-show-animation-options='{
                         "targetSelector": "#signupModalForm",
                         "groupName": "idForm"
                       }'>Sign up here</a>
                </p>
              </div>

              <!-- Form Group -->
              <div class="js-form-message form-group">
                <label class="input-label" for="signinModalFormSrEmail">Your email</label>
                <input type="email" class="form-control" name="email" id="signinModalFormSrEmail" placeholder="email@address.com" aria-label="email@address.com" required data-msg="Please enter a valid email address.">
              </div>
              <!-- End Form Group -->

              <!-- Form Group -->
              <div class="js-form-message form-group">
                <label class="input-label" for="signinModalFormSrPassword">
                    <span class="d-flex justify-content-between align-items-center">
                      Password
                      <a class="js-animation-link link text-muted" href="javascript:;"
                         data-hs-show-animation-options='{
                           "targetSelector": "#forgotPasswordModalForm",
                           "groupName": "idForm"
                         }'>Forgot Password?</a>
                    </span>
                </label>
                <input type="password" class="form-control" name="password" id="signinModalFormSrPassword" placeholder="8+ characters required" aria-label="8+ characters required" required data-msg="Your password is invalid. Please try again.">
              </div>
              <!-- End Form Group -->

              <button type="submit" class="btn btn-block btn-primary">Sign in</button>
            </div>
            <!-- End Sign in with Modal -->

            <!-- Sign up -->
            <div id="signupModalForm" style="display: none; opacity: 0;">
              <div class="text-center mb-5">
                <h2>Sign up</h2>
                <p>Already have an account?
                  <a class="js-animation-link" href="javascript:;"
                     data-hs-show-animation-options='{
                         "targetSelector": "#signinModalForm",
                         "groupName": "idForm"
                       }'>Sign in here</a>
                </p>
              </div>

              <a class="btn btn-block btn-white mb-2" href="#">
                  <span class="d-flex justify-content-center align-items-center">
                    <img class="avatar avatar-xss mr-2" src="assets/svg/brands/google.svg" alt="Image Description">
                    Sign up with Google
                  </span>
              </a>

              <a class="js-animation-link btn btn-block btn-primary mb-2" href="#"
                 data-hs-show-animation-options='{
                     "targetSelector": "#signupWithEmailModalForm",
                     "groupName": "idForm"
                   }'>Sign up with Email</a>

              <div class="text-center mt-3">
                <p class="font-size-1 mb-0">By continuing you agree to our <a href="#">Terms and Conditions</a></p>
              </div>
            </div>
            <!-- End Sign up -->

            <!-- Sign up with Modal -->
            <div id="signupWithEmailModalForm" style="display: none; opacity: 0;">
              <div class="text-center mb-5">
                <h2>Sign up</h2>
                <p>Already have an account?
                  <a class="js-animation-link" href="javascript:;"
                     data-hs-show-animation-options='{
                         "targetSelector": "#signinModalForm",
                         "groupName": "idForm"
                       }'>Sign in here</a>
                </p>
              </div>

              <!-- Form Group -->
              <div class="js-form-message form-group">
                <label class="input-label" for="signupModalFormSrEmail">Your email</label>
                <input type="email" class="form-control" name="email" id="signupModalFormSrEmail" placeholder="email@address.com" aria-label="email@address.com" required data-msg="Please enter a valid email address.">
              </div>
              <!-- End Form Group -->

              <!-- Form Group -->
              <div class="js-form-message form-group">
                <label class="input-label" for="signupModalFormSrPassword">Password</label>
                <input type="password" class="form-control" name="password" id="signupModalFormSrPassword" placeholder="8+ characters required" aria-label="8+ characters required" required data-msg="Your password is invalid. Please try again.">
              </div>
              <!-- End Form Group -->

              <!-- Form Group -->
              <div class="js-form-message form-group">
                <label class="input-label" for="signupModalFormSrConfirmPassword">Confirm password</label>
                <input type="password" class="form-control" name="confirmPassword" id="signupModalFormSrConfirmPassword" placeholder="8+ characters required" aria-label="8+ characters required" required data-msg="Password does not match the confirm password.">
              </div>
              <!-- End Form Group -->

              <button type="submit" class="btn btn-block btn-primary">Sign up</button>

              <div class="text-center mt-3">
                <p class="font-size-1 mb-0">By continuing you agree to our <a href="#">Terms and Conditions</a></p>
              </div>
            </div>
            <!-- End Sign up with Modal -->

            <!-- Forgot Password -->
            <div id="forgotPasswordModalForm" style="display: none; opacity: 0;">
              <div class="text-center mb-5">
                <h2>Forgot password?</h2>
                <p>Enter the email address you used when you joined and we'll send you instructions to reset your password.</p>
              </div>

              <!-- Form Group -->
              <div class="js-form-message form-group">
                <label class="input-label" for="resetPasswordSrEmail" tabindex="0">
                  <span class="d-flex justify-content-between align-items-center">
                    Your email
                    <a class="js-animation-link d-flex align-items-center link text-muted" href="javascript:;"
                       data-hs-show-animation-options='{
                         "targetSelector": "#signinModalForm",
                         "groupName": "idForm"
                       }'>
                      <i class="fas fa-angle-left mr-2"></i> Back to Sign in
                    </a>
                  </span>
                </label>
                <input type="email" class="form-control" name="email" id="resetPasswordSrEmail" tabindex="1" placeholder="Enter your email address" aria-label="Enter your email address" required data-msg="Please enter a valid email address.">
              </div>
              <!-- End Form Group -->

              <button type="submit" class="btn btn-block btn-primary">Submit</button>
            </div>
            <!-- End Forgot Password -->
          </form>
        </div>
        <!-- End Body -->

        <!-- Footer -->
        <div class="modal-footer d-block text-center py-sm-5">
          <small class="text-cap mb-4">Trusted by the world's best teams</small>

          <div class="w-85 mx-auto">
            <div class="row justify-content-between">
              <div class="col">
                <img class="img-fluid" src="assets/svg/brands/gitlab-gray.svg" alt="Image Description">
              </div>
              <div class="col">
                <img class="img-fluid" src="assets/svg/brands/fitbit-gray.svg" alt="Image Description">
              </div>
              <div class="col">
                <img class="img-fluid" src="assets/svg/brands/flow-xo-gray.svg" alt="Image Description">
              </div>
              <div class="col">
                <img class="img-fluid" src="assets/svg/brands/layar-gray.svg" alt="Image Description">
              </div>
            </div>
          </div>
        </div>
        <!-- End Footer -->
      </div>
    </div>
  </div>
  <!-- End Sign Up Modal -->
  <!-- ========== END SECONDARY CONTENTS ========== -->

  <!-- Go to Top -->
  <a class="js-go-to go-to position-fixed" href="javascript:;" style="visibility: hidden;"
     data-hs-go-to-options='{
       "offsetTop": 700,
       "position": {
         "init": {
           "right": 15
         },
         "show": {
           "bottom": 15
         },
         "hide": {
           "bottom": -15
         }
       }
     }'>
    <i class="fas fa-angle-up"></i>
  </a>
  <!-- End Go to Top -->


  <!-- JS Implementing Plugins -->
  <script src="assets/js/vendor.min.js"></script>
  <script src="assets/vendor/hs-scroll-nav/dist/hs-scroll-nav.min.js"></script>

  <!-- JS Front -->
  <script src="assets/js/theme.min.js"></script>

  <!-- JS Plugins Init. -->
  <script>
    $(document).on('ready', function () {
      // INITIALIZATION OF HEADER
      // =======================================================
      var header = new HSHeader($('#header')).init();


      // INITIALIZATION OF MEGA MENU
      // =======================================================
      var megaMenu = new HSMegaMenu($('.js-mega-menu'), {
        desktop: {
          position: 'left'
        }
      }).init();


      // INITIALIZATION OF UNFOLD
      // =======================================================
      var unfold = new HSUnfold('.js-hs-unfold-invoker').init();


      // INITIALIZATION OF SHOW ANIMATIONS
      // =======================================================
      $('.js-animation-link').each(function () {
        var showAnimation = new HSShowAnimation($(this)).init();
      });


      // INITIALIZATION OF FORM VALIDATION
      // =======================================================
      $('.js-validate').each(function() {
        $.HSCore.components.HSValidation.init($(this), {
          rules: {
            confirmPassword: {
              equalTo: '#signupPassword'
            }
          }
        });
      });


      // INITIALIZATION OF STICKY BLOCKS
      // =======================================================
      $('.js-sticky-block').each(function () {
        var stickyBlock = new HSStickyBlock($(this)).init();
      });


      // INITIALIZATION OF SCROLL NAV
      // =======================================================
      $('.js-scroll-nav').each(function () {
        var scrollNav = new HSScrollNav($(this)).init();
      });


      // INITIALIZATION OF GO TO
      // =======================================================
      $('.js-go-to').each(function () {
        var goTo = new HSGoTo($(this)).init();
      });
    });
  </script>

  <!-- IE Support -->
  <script>
    if (/MSIE \d|Trident.*rv:/.test(navigator.userAgent)) document.write('<script src="assets/vendor/babel-polyfill/dist/polyfill.js"><\/script>');
  </script>
</body>

<!-- Mirrored from htmlstream.com/front/page-terms.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 19 May 2021 14:20:42 GMT -->
</html>